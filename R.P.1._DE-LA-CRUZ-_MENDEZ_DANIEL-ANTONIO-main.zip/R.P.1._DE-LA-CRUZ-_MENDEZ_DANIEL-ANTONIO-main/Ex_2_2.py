print('coloca los datos para la media')
a=float(input('ingresa el primer dato:'))
b=float(input('ingrese el segundo dato:'))
c=float(input('ingrese el tercer dato:'))
#calculamos
r= a+b+c
r2=r/3
print('la media es =', r2)