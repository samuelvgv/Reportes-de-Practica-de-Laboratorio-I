
contraseñacorrecta="iloveyou123"
contraseña=input("ingrese la contraseña")
while (contraseña!=contraseñacorrecta):
  print("la contraseña es incorrecta")
  string= input("intentelo de nuevo")
  
print("contraseña correcta")
print("bienvenido")