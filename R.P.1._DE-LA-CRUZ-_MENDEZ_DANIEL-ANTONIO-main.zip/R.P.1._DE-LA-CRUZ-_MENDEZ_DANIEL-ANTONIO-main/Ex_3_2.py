
c=input("escribe un caracter")
if ( c=="b" or c=="c" or c=="d" or  c=="f" or c=="g" or c=="h" or c=="j" or c=="k" or c=="l" or c=="m" or c=="n" or c=="ñ" or c=="p" or c=="q" or c=="r" or c=="s" or c=="t" or c=="w" or c=="x" or c=="y" or c=="z"):
    print( c ,"es una vocal") 
else:
    print("no es la letra c")
    if ( c=="b" or c=="c" or c=="d" or  c=="f" or c=="g" or c=="h" or c=="j" or c=="k" or c=="l" or c=="m" or c=="n" or c=="ñ" or c=="p" or c=="q" or c=="r" or c=="s" or c=="t" or c=="w" or c=="x" or c=="y" or c=="z"):
        print(c, "esta en minuscula")
    else:
        print(c, "esta en mayuscula")
        if ( c=="b" or c=="c" or c=="d" or  c=="f" or c=="g" or c=="h" or c=="j" or c=="k" or c=="l" or c=="m" or c=="n" or c=="ñ" or c=="p" or c=="q" or c=="r" or c=="s" or c=="t" or c=="w" or c=="x" or c=="y" or c=="z"):
            print(c, "es un simbolo del alfabeto")
        
   
    
    

