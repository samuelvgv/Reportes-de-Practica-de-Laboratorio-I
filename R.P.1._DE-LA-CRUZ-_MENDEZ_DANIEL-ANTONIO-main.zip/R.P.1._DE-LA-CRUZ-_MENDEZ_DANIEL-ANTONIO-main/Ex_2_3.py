print('coloca las coordenadas:')
ax=float(input("punto x en la primera coordenada:"))
ay=float(input('punto y en la primera coordenada:'))
bx=float(input("punto x en la segunda coordenada:"))
by=float(input("punto y en la segunda coordenada:"))
#operaciones
A=(ax+ay)/2
B=(bx+by)/2
M=A+B
print('la media en los dos puntos son=', M)
