# PracticaPython
Ejercicios del documento pdf de python
las practicas dejadas por el docente son un refuerzo para el uso de los diferentes metodos, que tiene el lenguaje de python. 
En nuestro sistema como electronicos, este lenguaje es muy ocupado ya que su tiempo de respuesta es el mas veloz, como para crear las inteligencias artificiales.
El Documento dado explicaba los metodos de como funcionaban, ejemplos y ejercicios. Por esta razon se publico en esta plataforma ya que es considerada como una de las mejores para subir los codigos. 
Cada Codigo tienen funciones diferentes, ya que por cada uno usa un metodo diferente.
Los archivos con inicio Ex_1 tienen metodos basicos como print, variables y operadores.
Los archivos con inicio Ex_2 Se usan las variebles para que el usuario ingrese un dato ya sea numerico, boleano o texto.Tambien tiene explicacion de los operadores, signos arimeticos, los tipos de entradas.
Los Archivos con inicio Ex_3 contienen las condiciones y variables como los if, elif, else y conectores logicos.
Los Archivos con inicio Ex_4 contiene las condiciones iniciales como son los while, for, break que su funcion es hacer un bucle que no tengan fin sin que el usuario ponga hasta que cantidad debe parar.
Los Archivos con inicio Ex_5 contienen las funciones de los vectores, ya que con esto podemos crear listas como hacer bases de datos, lista de alumnos, hacer cambios pero con ayuda de las funciones de while y for.
