print('Suma de dos reales')
a = float( input('Entre el dato 1: ') )
b = float( input('Entre el dato 2: ') )
suma = a + b
print('La suma vale:' , suma)