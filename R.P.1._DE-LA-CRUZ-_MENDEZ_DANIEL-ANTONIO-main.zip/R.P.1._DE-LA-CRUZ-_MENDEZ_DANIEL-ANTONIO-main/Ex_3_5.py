i=float(input('ingrese un numero'))
if(i<0):
    print("el numero es negativo")
    if (i>0):
        print("el numero es positivo")
        if (i==0):
            print("le numero es cero")
            
            
