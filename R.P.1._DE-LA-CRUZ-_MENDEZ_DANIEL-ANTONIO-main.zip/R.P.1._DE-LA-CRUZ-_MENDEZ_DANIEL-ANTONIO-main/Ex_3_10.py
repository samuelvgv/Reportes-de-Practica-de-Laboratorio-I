print('escriba la medida del tornillo')
a=float(input('medida del tornillo en cm'))
if a<=2.9:
    print('el tornillo es pequeño')
else:
        if (a>2.9) and (a<=4.9):
            print('tornillo es mediano')
        else:
                if (a>4.9) and (a<=6.4):
                    print('tornillo es grande')
                else:
                     print('el tornillo es muy grande')
                    
            
    