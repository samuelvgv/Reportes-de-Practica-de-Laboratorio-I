print('Suma de dos enteros')
a = int( input('Entre el dato 1: ') )
b = int( input('Entre el dato 2: ') )
suma = a + b
print('La suma vale:' , suma)